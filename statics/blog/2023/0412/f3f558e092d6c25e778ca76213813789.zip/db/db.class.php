<?php
require 'db_config.php';

class DB {
    private static $conn;
    public static function init($config) {
        require('mypdo.class.php');
        self::$conn = new Mypdo($config);
        if (!self::$conn) {
            $res = [
                'error' => 5,
                'msg' => '数据库链接错误',
                'data' => false
            ];
            echo json_encode($res, JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    public static function handle($sql, $parameters = [])
    {
        return self::$conn->handle($sql, $parameters);
    }

    // 执行查询
    public static function query($sql, $parameters = [])
    {
        return self::$conn->query($sql, $parameters);
    }


    /**
     * [增 删 改 返回受影响的行数以及 最后插入的id]
     * array(2) { ["row"]=>int(1)  ["lastId"]=> "0"}
     * @return   [arr]             [插入返回成功的Id 和受影响的行数]
     */
    public static function getResult()
    {
        return self::$conn->getResult();
    }

    // 返回失败状态的信息
    public static function getError()
    {
        return self::$conn->getError();
    }

}

DB::init($config);