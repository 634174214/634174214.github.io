<?php

class Mypdo {
    // mysql链接
    private $dsn;
    // 数据库用户名
    private $user;
    // 数据库密码
    private $password;
    // 数据库字符集
    private $charset;
    // PDO对象
    private $pdoInstance;
    // sql对象 查询获取的资源
    private $pdoStmt;
    // 存储错误码
    private $errArr;
    // 存储更新成功后影响的行数以及插入的id
    private $result;

    public function __construct($config) {
        if (!isset($config)) {
            return false;
        }
        $this->dsn = "mysql:host={$config['dbhost']};dbname={$config['dbname']}";
        $this->user = $config['dbuser'];
        $this->password = $config['dbpsw'];
        $this->charset = $config['dbcharset'];
        if (!$this->connect()) {
            return false;
        }
    }

    private function connect()
    {
        if (!$this->pdoInstance) {
            $options = array(
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES '.$this->charset
            );

            $this->pdoInstance = new PDO($this->dsn, $this->user, $this->password, $options);
            if (!$this->pdoInstance) {
               return false;
            }
            $this->pdoInstance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
    }

    public function query($sql, $parameters = []) {
        if (!is_array($parameters)) {
            $parameters = array($parameters);
        }
        $this->pdoStmt = $this->pdoInstance->prepare($sql);
        $index = 1;
        foreach ($parameters as $parameter) {
            $this->pdoStmt->bindValue($index++, $parameter[0], $parameter[1]);
        }
        $execRe = $this->pdoStmt->execute();
        if (!$execRe) {
            $this->errArr = array(
                'code' => $this->pdoStmt->errorCode(),
                'info' => $this->pdoStmt->errorInfo()[2]
            );
            return false;
        }
        $data = $this->pdoStmt->fetchAll(PDO::FETCH_ASSOC);
        return $data;
    }

    // 增 删 改 操作
    public function handle($sql, $parameters = [])
    {
        if (!is_array($parameters)) {
            $parameters = array($parameters);
        }
        $this->pdoStmt = $this->pdoInstance->prepare($sql);
        if (count($parameters) > 0) {
            $index = 1;
            foreach ($parameters as $parameter) {
                // var_dump($parameter);
                $this->pdoStmt->bindValue($index++, $parameter[0], $parameter[1]);
            }
        }
        $execRe = $this->pdoStmt->execute();
        // var_dump($sql);
        // exit();
        if (!$execRe) {
            $this->errArr = array(
                'code' => $this->pdoStmt->errorCode(),
                'info' => $this->pdoStmt->errorInfo()[2]
            );
            return false;
        }
        $this->result = [
            // 影响的行数
            'row' => $this->pdoStmt->rowCount(),
            // 插入的id
            'lastId' => $this->pdoInstance->lastInsertId()
        ];
        return true;
    }

    public function getError()
    {
        // 如果错误状态数组返回true
        if ((bool)$this->errArr) {
            $err = $this->errArr;
        } else {
            $err = array();
        }
        return $err;
    }

    // 返回插入 修改 删除的结果
    public function getResult()
    {
        if (!is_array($this->result) && empty($this->result)) {
            $this->result = array();
        }
        return $this->result;
    }


}