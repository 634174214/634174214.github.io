<?php
$config = array(
    'dbhost' => 'localhost',
    'dbuser' => 'design0505',
    'dbpsw' => 'sj0505',
    'dbname' => 'xincards',
    'dbcharset' => 'utf8'
);