<?php
require ('phpqrcode.php');
$url = urldecode($_GET["data"]);
$size = intval($_GET["size"]);
if( $size < 1 || $size > 9 )  {
    $size = 5;
};

//if( preg_match( '/^https*:\/\/[\w\.]+?\.(wubin\.work)\//i', $url )==1 ) {
//  QRcode::png( $url, false, 1, $size );
//}
/* QRcode::png( $url, $outfile, $level, $size, $margin , $saveandprint )
$url表示生成二位的的信息文本；
$outfile表示是否输出二维码图片 文件，默认否；
$level表示容错率，也就是有被覆盖的区域还能识别，分别是 L（QR_ECLEVEL_L，7%），M（QR_ECLEVEL_M，15%），Q（QR_ECLEVEL_Q，25%），H（QR_ECLEVEL_H，30%） 传字符串；
$size表示生成图片大小，默认是3；
$margin表示二维码周围边框空白区域间距值；
$saveandprint表示是否保存二维码并 显示
*/

// 获取二维码但并不输出
// $qr = QRcode::png( $url, false, QR_ECLEVEL_L, $size, 3 );

$dir = str_replace('\\', '/', __DIR__);
$logo = $dir . '/logo.png';

// 如果需要logo 需要手动执行，传入Logo的路径，如果没传入那么会直接生成没有logo的二维码
QRimage::setLogo(array(
    // logo图片的路径，必须
    'path' => $logo,
    // logo占QR宽度的几分之一 比率, 值越大 logo越小
    'ratio' => 5
));

// 这里如果传入图片路径就不会生成图片 经过测试L无法识别
QRcode::png($url, false, QR_ECLEVEL_M, $size, 3);



