原文地址：https://www.cnblogs.com/xxcanghai/p/6124699.html

propsync: 
https://github.com/xxcanghai/cnblogsFiles/tree/master/vue-mixins
https://github.com/xxcanghai/cnblogsFiles/blob/master/vue-mixins/propsync.js