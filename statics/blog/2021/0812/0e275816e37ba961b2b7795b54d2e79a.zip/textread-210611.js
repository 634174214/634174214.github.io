
function IsPC() {
        var userAgentInfo = navigator.userAgent;
        var Agents = ['Android', 'iPhone',
            'SymbianOS', 'Windows Phone',
            'iPad', 'iPod'
        ];
        var flag = true;
        for (var i = 0; i < Agents.length; i++) {
            if (userAgentInfo.indexOf(Agents[i]) != -1) {
                flag = false;
                break;
            }
        }
        return flag;
}

function whospeak(set1,set2){
  var speaker_array=[set1,set2];
  var i=Math.floor(Math.random()*speaker_array.length);
  var speaker=speaker_array[i];
  // console.log(speaker);
  return speaker;
}


function getByteLen(val) {
        var len = 0;
        for (var i = 0; i < val.length; i++) {
            var a = val.charAt(i);
            if (a.match(/[^\x00-\xff]/ig)!=null){
                len += 2;
            }else{
                len += 1;
            }
        }
        return len;
}


var audio = null;
var p_all=$('#Cnt-Main-Article-xin p').not('.guide-p');
var state='noread';
var readingtimer;


function setreadtext(obj) {
  var read='';
  $('body').append($('<div id="readtext"></div>'));
  for(var i=0;i<obj.length;i++){
      read = read + obj.eq(i).text()+'，、。';
      $('#readtext').html(read);
  }
}
setreadtext(p_all);


var text_len=getByteLen($('#readtext').text());
if(IsPC()){
    $('#readbtn').hide();
}else{
   if (text_len<4096) {//百度语音合成2018-07-14 更新合成限制2048个汉字
     $('#readbtn').removeClass('readhide');
     $('.readNum').addClass('spaceR');
     var readbtn_top=$('#readbtn').offset().top;
     console.log(readbtn_top);
   }
}

// 合成
function tts(text) {
    var speaker= whospeak(0,1);
    audio = btts({
        tex: text,
        tok: '24.8f04263ca04147bd8ae82cb7fdff03a2.2592000.1625266802.282335-11551515',
        lan:'zh',//语言选择,
        ctp:1,
        spd: 5,//语速，取值0-9，
        pit: 5,//音调，取值0-9，
        vol: 9,//音量，取值0-9，
        per: speaker//发音人选择, 0为普通女声，1为普通男生，3为情感合成-度逍遥，4为情感合成-度丫丫
    }, {
        volume: 0.3,
        autoDestory: true,
        timeout: 10000,
        hidden: false,
        autoDestory:true,
        onInit: function (htmlAudioElement) {

        },

        onSuccess: function(htmlAudioElement) {
            audio = htmlAudioElement;
            audio.play();
            audio.onended=function(){
                   $('#readbtn').attr('class','readon').removeAttr("style");
                   $('#readbtn span').html('语音播报');
                   state='noread';
                   $(this).remove();
            };
        },
        onError: function(text) {
            alert('大爷，小信嗓子哑了，您在刷新一下页面听听。');
            playerror();
        },
        // 合成超时
        onTimeout: function () {
            alert('大爷,小信睡着了,您在刷新一下页面听听。');
            playerror();
        }
    });
}


function cover_btn(){
  var btn_cover;
  clearTimeout(btn_cover);
  $('#audioloading').fadeIn();
  btn_cover=setTimeout(function(){
      $('#audioloading').fadeOut();
  },3000);
}

function playerror(){//播放错误
  $('#readbtn').off('click');
  $('#readbtn em').remove();
  $('#readbtn').attr('class','readon').css('top','auto');
  $('#readbtn span').text('语音播放');
}

$('#readbtn').on('click',function(){
      // 没有开始读
      if (state=='noread') {
             tts($('#readtext').text());
             cover_btn();
             $(this).attr('class','reading');
             // $(this).css('top',readbtn_top);
             $('span',this).html('正在播放');
             state='reading';
      // 正在阅读点击暂停
      } else if(state=='reading'){
              $(this).attr('class','readoff');
              $('span',this).html('继续播放');
              audio.pause();
              state='waiting';
      // 暂停时候点击继续阅读
      }else if(state=='waiting'){
         $(this).attr('class','reading');
         $('span',this).html('正在播放');
         audio.play();
         state='reading';
      }
      return false;
});

