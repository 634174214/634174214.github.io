<template>
  <transition name="confirm-fade">
    <div class="cofirm" v-if="show">
      <div class="cofirm-inner" @click.stop>
        <div class="head">
          <p class="head-text"><em>{{content.headText ? content.headText : '系统提示'}}</em></p>
          <div class="close" @click="cancel">×</div>
        </div>
        <div class="body">
          <div class="content">{{content.title}}</div>
          <div class="tips-btn">
            <button
                type="button"
                v-if="content.confirm"
                @click="confirm"
                class="btn confirm"
            >
              {{content.confirm}}
            </button>
            <button type="button"
                    v-if="content.cancel"
                    @click="cancel"
                    class="btn"
            >{{content.cancel}}</button>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  data(){
    return {
      // 决定是否显示
      show :false,
      // 弹窗的内容
      content: {
        headText: '',
        title:'',
        cancel:'',
        confirm:''
      }
    }
  },
  methods:{
    confirm(){
      return true;
    },
    cancel(){
      return false;
    }
  }
};
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @confirm-dialog-bg: rgba(46, 62, 78, 0.85);
  @confirm-gray-lite: #e6e6e6;
  @confirm-brand: #518ACA;
  @confirm-gray-dark: #4d4d4d;
  @confirm-gray-middle: #dedede;

  @keyframes confirmInDown {
    0% {
      opacity: 0;
      transform: translate(-50%, -80%);
    }
    100% {
      opacity: 1;
      transform: translate(-50%, -50%);
    }
  }

  .cofirm{
    background-color: @confirm-dialog-bg;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9999;
    user-select: none;
  }
  .confirm-fade-enter-active,
  .confirm-fade-leave-active {
    transition: opacity 0.5s ease;
  }
  .confirm-fade-enter, .confirm-fade-leave-to {
    opacity: 0;
  }
  .cofirm-inner {
    position: absolute;
    background-color: #fff;
    overflow: hidden;
    border-radius: 5px;
    box-shadow: 0 3px 3px rgba(0,0,0, 0.4);
    width: 360px;
    left: 50%;
    top: 50%;
    animation: confirmInDown 0.4s both;
    .head{
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid @confirm-gray-lite;
      height: 40px;
      padding: 0 15px;
      font-size: 14px;
      line-height: 40px;
      color: darken(@confirm-gray-lite, 30%);

      .head-text{
        font-size: 0;
        em{
          font-size: 14px;
          display: inline-block;
        }
      }
      .head-text::before{
        content: "!";
        display: inline-block;
        font-size: 12px;
        border: 1px solid;
        border-radius: 50%;
        vertical-align: 2px;
        width: 14px;
        height: 14px;
        line-height: 14px;
        margin-right: 5px;
        text-align: center;
      }
      .close {
        text-align: right;
        font-size: 20px;
        color: darken(@confirm-gray-lite, 20%);
        cursor: pointer;
        &:hover{
          color: @confirm-brand;
        }
      }
    }

    .body{
      padding: 15px;

      .content {
        font-size: 16px;
        color: @confirm-gray-dark;
        letter-spacing: 0;
        line-height: 24px;
        text-align: left;
        padding: 10px 0 25px;
      }

      .tips-btn{
        display: flex;
        width: 100%;
        justify-content: flex-end;
        align-items: center;
        .btn{
          padding: 0 22px ;
          height: 36px;
          line-height: 36px;
          border-radius: 6px;
          background-color: #fff;
          border: 1px solid @confirm-gray-middle;
          &:hover{
            background-color: @confirm-gray-lite;
          }
          & + .btn{
            margin-left: 10px;
          }
          &.confirm{
            background-color: @confirm-brand;
            color: #fff;
            border: 1px solid @confirm-brand;
            &:hover{
              background-color: darken(@confirm-brand, 10%);
            }
          }
        }
      }

    }
  }


</style>
