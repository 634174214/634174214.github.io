import Vue from 'vue';
import App from './App.vue';

import { confirmChoose, alertChoose } from "common/js/confirm";



// 将方法挂载到vue的原型链上 使用：this.$confirm
Vue.prototype.$confirm = confirmChoose;
// 挂载到window上,直接覆盖原来的方法
window.alert = alertChoose;



new Vue({
  render: h => h(App),
}).$mount('#app');

