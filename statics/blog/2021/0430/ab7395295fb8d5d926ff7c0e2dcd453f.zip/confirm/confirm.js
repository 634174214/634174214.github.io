import Vue from 'vue';
import Confirm from 'components/confirm/confirm';

const confirmConstructor = Vue.extend(Confirm);

// 先封装一个异步操作
let confirmer = function (msg) {
  return  new Promise((resolve, reject) => {
    // 以下两句等价
    // let confirmEl = new confirmConstructor({
    //   实例化后要绑定的元素
    //   el: document.createElement('div')
    // });
    // $mount()为手动挂载 带元素id为挂载到指定元素上，不加元素不渲染, 只是实例化该组件
    // 如new Vue时 new Vue({el: '#app', data: {...}}) 等同于 new Vue({data: {...}}).$mount('#app')
    let confirmEl = new confirmConstructor().$mount();

    // 动态将实例化的组件的DOM结构插入到body中， 也可以在public/index.html中 写一个 <div id="alert">
    // new Vue({data: {...}}).$mount('#alert')
    document.body.appendChild(confirmEl.$el);
    // 如果每一项都要设置就使用这种方式,传值的时候就传一个对象
    // confirmEl.content = content;
    confirmEl.content = {
      title: msg,
      confirm: '确定',
      cancel: '取消'
    };
    confirmEl.show = true;
    // 监听确定的事件
    confirmEl.confirm = function () {
      resolve(true);
      confirmEl.show = false;
    };
    // 接收取消的事件
    confirmEl.cancel = function () {
      reject(false);
      confirmEl.show = false;
    };
  });
};

// 这个仅仅做提示用，无需根据返回值判断
let alertChoose = function(msg) {
  let confirmEl = new confirmConstructor({
    // 实例化后要绑定的元素
    el: document.createElement('div')
  });
  document.body.appendChild(confirmEl.$el);
  confirmEl.show = true;
  confirmEl.content.title = msg;
  confirmEl.content.confirm = '确定';
  confirmEl.confirm = function () {
    confirmEl.show = false;
  };
  confirmEl.cancel = function () {
    confirmEl.show = false;
  };
};

async function confirmChoose(content) {
  let sure = false;
  try {
    // await后面是一个promise对象
    sure =  await confirmer(content);
  } catch (e) {
    // 捕获到错误 转为立即resolve的promise对象
    sure = false;
  }
  return sure;
}

export { confirmChoose, alertChoose };
