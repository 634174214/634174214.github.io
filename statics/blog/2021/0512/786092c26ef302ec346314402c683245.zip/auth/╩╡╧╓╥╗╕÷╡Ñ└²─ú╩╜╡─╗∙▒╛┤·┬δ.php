<?php

/**
 * 单例 一次请求中所有出现使用JWT的地方都是一个用户
 */
class JwtAuth
{
    // 单例模式 jwtauth句柄
    private static $instance;

    // 获取jwtauth的句柄
    public static function getInstance()
    {   
        // 判断当前类是否为空，为空则new本身
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        //  保证每次通过getInstance方法拿到的句柄是同一个句柄
        return self::$instance;
    }

    // 将类的构造函数私有化，防止其他人new这个类，否则外部可以再声明一个类
    private function __construct()
    {

    }

    // 将clone函数也私有化，以保证在当前进程中，这个php就是一个单例，防止外部去克隆这个类
    private function __clone()
    {
        // 
    }
}