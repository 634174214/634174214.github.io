<?php
// 依赖于composer的autoload
// require('../vendor/autoload.php');
use \Firebase\JWT\JWT;

/**
 * 单例 一次请求中所有出现使用JWT的地方都是一个用户
 */
class JwtAuth
{
    // jwt token
    private $token;

    // 相当于哪个网站颁发的token
    private $iss = 'www.wubin.work';

    // 谁去接收
    private $aud = 'tool.wubin.work';

    // 将用户uid等身份信息编码到jwt中
    private $uid;

    /*
    使用非对称加密：私钥放在程序里的，公钥是可以放在任何客户端的，你可以理解成 这是两把钥匙，一把钥匙（私钥）你自己留着
另一把钥匙（公钥）你可以复制给任何人，当你有一个文件想要加密发送给别人 就用你的私钥把文件加密 然后把加密后的文件发给别人，别人拿到你这个加密后的文件 可以用公钥解密 读到文件内容，因为私钥只有你自己知道 这样别人就没法伪装成你 给别人发信息。
私钥：用于加密 公钥：用于解密
     */
    // 用于加密的私钥
    private $privateKey = <<<EOD
-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDWd6sYW3eriCT+I3E171E0IsB7X00Y2nKocQaL5qrpSX9gra+U
soj2HE6RBJ3asdEP9zSGuBsUSvsbwu7aNxQJ5ChfGEMTv20JK5SLnLhcI1BsXNzz
3OILUrZOPGk5tCuEeV4mGH5thXWryMt37p4kTSgAB/GIzy4SJZO1S/Hu0wIDAQAB
AoGBAKX+ESrVAJZ+1ULt452/ELatfxT9+goWaU/9yvdVHUtaW4BUbeVFGcSCvDx5
ukOeBRW6W6k5rZvTPO+LvJqgrpxebOxcW7d//9IFfZbGGd859/u3ej1wQ7O0emVV
C9f5/3gyyiEBEjJhxDwiGV5uD1B1lbASBX5FEmBhkEL8C5HBAkEA8A+smv4TEkSi
u5IsrbOS0ji4U/9cegFgAm/rV9KiucjSvE7PgtA+aUk+eBj1e23YDCrmrWGKOTpz
opvigQrdGQJBAOS0+egptakQKiuyNEdWJ/9v+bmo0O2+MFRNSAajkLXpZUa/k+YS
YNUesJbIBud7KUjFMOThbhwYdFHT96Iw/MsCQFZGO9EkGLSLCDUDDp2KmOyGR/Cg
KJsMXXXixSC16Zd9TgcxB7DKqHNsSFAfIDIwwuF0lZygHm38zMwW2+tmfRkCQQDA
QbJjC8z+FeydVuzDmxV8kXDoNZWMhXizJVQK4KzhfxX350w49/IWtfnUhsnnBY2q
8rkrbqXVUGlX8EwXN/8JAkAGk3tnTs4CeEKWpwu0wawYiawSKPRdKyriNZzNDwPq
s4mRqBeMnx7qqOPIvPl3JL8iZMzC8qyhSsCm53fWOHPc
-----END RSA PRIVATE KEY-----
EOD;
    
    // 用于解密的公钥
    public $publicKey = <<<EOD
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDWd6sYW3eriCT+I3E171E0IsB7
X00Y2nKocQaL5qrpSX9gra+Usoj2HE6RBJ3asdEP9zSGuBsUSvsbwu7aNxQJ5Chf
GEMTv20JK5SLnLhcI1BsXNzz3OILUrZOPGk5tCuEeV4mGH5thXWryMt37p4kTSgA
B/GIzy4SJZO1S/Hu0wIDAQAB
-----END PUBLIC KEY-----
EOD;

    // 单例模式 jwtauth句柄
    private static $instance;

    // 获取jwtauth的句柄
    public static function getInstance()
    {   
        // 判断当前类是否为空，为空则new本身
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        //  保证每次通过getInstance方法拿到的句柄是同一个句柄
        return self::$instance;
    }

    // 将类的构造函数私有化，防止其他人new这个类，否则外部可以再声明一个类
    private function __construct()
    {

    }

    // 将clone函数也私有化，以保证在当前进程中，这个php就是一个单例，防止外部去克隆这个类
    private function __clone()
    {
        // 
    }

    // 获取token 需要encode后才能调用这个函数,将通过encode获取到的token转成字符串
    public function getToken()
    {
        // 将对象强转为字符串
        return (string)$this->token;
    }

    // 设置token
    public function setToken($token)
    {
        $this->token = $token;

        return $this;
    }

    // 设置jwt的身份信息
    public function setUid($uid)
    {
        $this->uid = $uid;
        // 支持链式调用
        return $this;
    }

    // 编码jwt token
    public function encode()
    {
        // 当前时间
        $time = time();
        $payload = array(
            // 签发者
            "iss" => $this->iss,
            // 接收该JWT的一方
            "aud" => $this->aud,
            //签发时间
            "iat" => $time,
            //(Not Before)：某个时间点后才能访问，比如设置time+30，表示当前时间30秒后才能使用
            "nbf" => $time,
            //过期时间,这里设置2个小时
            'exp' => $time + 7200,
            //自定义信息，不要定义敏感信息
            'data' => [ 
                    'uid' => $this->uid,
                    'uname' => '李小龙'
            ]

        );

        /**
         * $payload 生成JWT的各种信息
         * $this->privateKey 用于加密的私钥
         * 'RS256' header中的alg，解码时要与之相同
         * @var [type]
         */
        $this->token = JWT::encode($payload, $this->privateKey, 'RS256');

        // 如果要产生链式调用，就需要返回一个this对象                              
        return $this;
    }

    public function decode()
    {
        /**
         * $this->token 传入之前jwt生成的token，
         * $this->publicKey 用于解密的公钥
         * array('RS256') 加密时的私钥alg 注意是一个数组
         * @var [type]
         */
        $decoded =  JWT::decode($this->token, $this->publicKey, array('RS256'));
        // 转换生成的是一个对象，需要转化为数组
        $decoded_array = (array) $decoded;
        return $decoded_array;
    }
}