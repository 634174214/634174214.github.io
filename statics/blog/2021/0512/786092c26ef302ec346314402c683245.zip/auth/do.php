<?php
// 使用composer安装 或者直接引用都可以
// require('../vendor/autoload.php');
require('php-jwt/JWT.php');
require('trait-json-class.php');
require('jwtauth.php');

class JwtLogin
{
    // 使用trait
    use ResponseJson;

    // 单独存放生成的token 用于解密
    public $jwtToken = '';

    // 模拟登陆 验证成功获取用户Id并返回一个Jwt
    public function login()
    {
        // 获取客户端传递的参数 去数据库验证username和password是否是匹配的，然后获取到用户uid的信息
        
        // 去数据库或缓存中读取用户信息的Uid
        $uid = 10;

        // 获取uid的句柄
        $jwtAuth = JwtAuth::getInstance();
        // 类中每个方法都返回$this 因此可以链式调用
        $token = $jwtAuth->setUid($uid)
                         ->encode()
                         ->getToken();

        // 单独存放token 用于解密
        $this->jwtToken = $token;

        return $this->jsonSuccessData([
            'token' => $token
        ]);                 var_dump($decode);
    }

    // 根据jwt获取用户信息
    public function getUser($token)
    {
        $jwtAuth = JwtAuth::getInstance();
        $decode = $jwtAuth->setToken($token)
                          ->decode();
        return $decode;
    }
}

$login = new JwtLogin();

$jwt = $login->login();

echo $jwt;

echo "<br><br><br><br>";

// 单独获取生成的token
$jwt_token = $login->jwtToken;

// 用户每次请求都会带上这个token, 这样就可以验证用户鉴权信息，对token的过期时间进行验证
try {
    // 模拟用户修改了token
    // $jwt_token = substr($jwt_token, 5);
    $user_info = $login->getUser($jwt_token);
    var_dump($user_info);
} catch(exception $err) {
    echo "用戶修改了token，出错了";
}


