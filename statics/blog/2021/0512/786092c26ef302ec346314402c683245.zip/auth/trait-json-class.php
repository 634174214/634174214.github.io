<?php

// 根据调用方给的data生成一个json对象
trait ResponseJson
{
    /**
     * 当app接口出现业务异常时的返回
     * 如1001 代表用户名不存在 1002代表密码错误那么此时code跟message都要变
     * @param    [type] $code    [description]
     * @param    [type] $message [description]
     * @param    array  $data    [description]
     * @return   [type]                            [description]
     */
    public function jsonData($code, $message, $data = [])
    {
        return $this->jsonResponse($code, $message, $data);
    }

    /**
     * APP接口请求成功时的返回 成功时候返回code一定是0 message一定是success
     * @param    array  $data [成功时候的返回]
     * @return   [json]       [description]
     */
    public function jsonSuccessData($data = [])
    {
        return $this->jsonResponse(0, 'success', $data);
    }


    /**
     * 返回一个json,接收错误码 错误信息 返回数据3个参数
     * 设置为private 在外部不会调用
     * @param    [type] $code    [错误码]
     * @param    [type] $message [错误码描述]
     * @param    [type] $data    [返回的数据]
     * @return   [type]          [返回一个json]
     */
    private function jsonResponse($code, $message, $data)
    {
        $content = [
            'code' => $code,
            'msg' => $message,
            'data' => $data
        ];

        // 将json转化为json串
        return json_encode($content);
    }
}
