<?php
header("content:application/json;chartset=uft-8");

$callback = isset($_GET['getjsonp']) ? $_GET['getjsonp'] : die('必须提供查询字段名称');

// 包裹json字符串的函数名
$funcName = 'jsonp_callback';

// 
if ($callback !== $funcName) {
    exit('函数名称不正确');
}

$res = [
    'code' => 0,
    'msg' => '返回成功',
    'data' => array(
        'title' => '这是一个标题',
        'desc' => '这是描述',
        'list' => array(
            '这是新闻1',
            '这是新闻2',
            '这是新闻3'
        )
    )
];

$json = json_encode($res, JSON_UNESCAPED_UNICODE);

// jsonp_callback({$json});
$jsonp = "{$funcName}({$json})";

echo $jsonp;

// 在当前目录下生成一个静态的js文件，用于html文件请求的
$filepath = str_replace('\\', '/', __DIR__);
$filename = $filepath . '/' . 'back-jsonp.js';
$file = file_put_contents($filename, $jsonp);
if (!$file) {
    exit('生成js文件失败');
}
