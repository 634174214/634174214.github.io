// 官网地址：https://github.com/webmodules/jsonp
// vue-cli中进行安装 $ npm install jsonp

// 对Jsonp函数的一次封装
import jsonp from 'jsonp';

function getJsonP(url) {
  return new Promise((resolve, reject) => {
    jsonp(
        url,
        {
          name: 'ztcallback'
        },
        (err, data) => {
          if (!err) {
            resolve(data);
          } else {
            reject(err);
          }
        }
    )
  });
}

export default getJsonP;

/* 如何使用 使用jsonp请求数据解决跨域问题

import getJsonP from "common/js/getJsonP";

return getJsonP(url).then(res => {
  return Promise.resolve(res);
}).catch(err => {
  return Promise.reject(err);
})

*/


