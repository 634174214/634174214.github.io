<?php
header("Access-Control-Allow-Origin: *");
header("content:application/json;chartset=uft-8");
require('fns.php');
require('upload.func.php');

// 名称字段不存在
define("ERR_CODE_NONAME", 1);
// 图片存储阶段失败
define("ERR_CODE_NOSAVE", 2);


// 配置基本信息
$maxSize = 2 * 1024 * 1024;                      // 每个文件大小
$allowExt = array('jpeg', 'jpg', 'png', 'gif');  // 每个文件支持的类型
$maxFilesCount = 5;                              // 一次最多上传的张数

// 专题id
$id = isset($_POST['id']) ? intval($_POST['id']) : false;

if (!isset($_FILES['imgfile']) || !$id) {
    showErr(ERR_CODE_NONAME, '缺少文章Id或者上传的图片不能为空！');
}

// 获取每个上传文件信息
$files = getMultipleFiles($_FILES['imgfile']);

if (count($files) > $maxFilesCount) {
    showErr(ERR_CODE_NONAME, '一次最多上传5张图片！');
}


// 存储目录的文件夹名称
$saveFolder = 'uploadfiles';
// 文件的存储路径(指向运行脚本所在的文件目录中)
$fileSavePath = getFilePath(__DIR__) . $saveFolder;
// 文件存储后可访问的http路径（指向运行脚本所在的文件目录中）
$currentFileName = basename(__FILE__);
$fileSaveServer = getFileUrl($currentFileName) . $saveFolder;

// 用于存储上传成功结果
$resSuccess = array();
$resError = array();


foreach ($files as $fileInfo) {
    $imgSaveRes = uploadFile($fileInfo, $allowExt, true, $maxSize, $fileSavePath, $fileSaveServer);
    if ($imgSaveRes['success']) {
        $resSuccess[] = $imgSaveRes['url'];
    } else {
        $resError[] = $imgSaveRes['filename'] . ':' . $imgSaveRes['msg'];
    }
}

// 图片总数量
$filesTotal = count($files);
$filesSuccess = count($resSuccess);
$fileErr = count($resError);

// 检测是否成功，只要有一张上传成功 则代表成功
if (count($resSuccess) > 0) {
    $msg = "上传成功！共{$filesTotal}张图片，成功上传{$filesSuccess}张，失败{$fileErr}张";
    showSuccess($resSuccess, $msg);
} else {
    // 只有都上传失败时，才代表上传失败
    $msg = implode(',', $resError);
    showErr(ERR_CODE_NOSAVE, $msg);
}