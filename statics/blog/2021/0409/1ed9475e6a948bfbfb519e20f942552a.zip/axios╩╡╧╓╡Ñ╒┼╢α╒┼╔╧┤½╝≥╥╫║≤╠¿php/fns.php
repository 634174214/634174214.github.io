<?php
function showSuccess($data = [], $msg = '提交成功', $code = 0) {
    $res = array(
        'error' => $code,
        'msg' => $msg,
        'data' => $data
    );

    $json = json_encode($res, JSON_UNESCAPED_UNICODE);

    exit($json);
}

function showErr($code = 2, $msg = '上传失败') {
    $res = array(
        'error' => $code,
        'msg' => $msg,
        'data' => false
    );
    $json = json_encode($res, JSON_UNESCAPED_UNICODE);

    exit($json);
}

// 检测图片地址是否有效
function checkImgExist($url) {
    if (!@getimagesize($url)) {
        return false;
    }
    return true;
}

function checkVideo($url) {
    $pattern = "/https?:\/\/[\/\w\d\-\.]+\.(mp4|wma|ogg)/i";
    $res = preg_match($pattern, $url, $match);
    return $res ? true : false;
}

// 检测一个url是否可以访问
function checkUrl($url) {
    // 如果函数方法不存在
    if (!function_exists('get_headers')) {
        return true;
    }
    $array = @get_headers($url, 1);
    if (!$array) {
        return false;
    }
    if( preg_match('/200/', $array[0]) &&
        preg_match('/video/', $array['Content-Type'])
    ){
        return true;
    } else {
        return false;
    }
}

function checkStrLength($str, $len) {
    $length = iconv_strlen($str);
    if ($length <= $len ) {
        return true;
    } else {
        return false;
    }
}


// 获取脚本文件夹路径
function getFilePath($dirpath) {
    $path = str_replace('\\', '/', $dirpath);
    $path .= '/';
    return $path;
}

// 获取脚本文件夹URL
function getFileUrl($filename) {
    $pageURL = 'http';
     
    if (isset($_SERVER["HTTPS"]) && 
        $_SERVER["HTTPS"] == "on"
    ) {
        $pageURL .= "s";
    }
    $pageURL .= "://";
     
    if ($_SERVER["SERVER_PORT"] != "80") {
        $pageURL .= $_SERVER["SERVER_NAME"].":" . $_SERVER["SERVER_PORT"] . $_SERVER['PHP_SELF'];
    } else {
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER['PHP_SELF'];
    }

    $pageURL = str_replace($filename, '', $pageURL);
    return $pageURL;
}