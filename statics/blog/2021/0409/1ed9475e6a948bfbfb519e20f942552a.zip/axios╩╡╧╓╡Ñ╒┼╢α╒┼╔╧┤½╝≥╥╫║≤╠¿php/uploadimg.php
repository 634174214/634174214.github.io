<?php
header("Access-Control-Allow-Origin: *");
header("content:application/json;chartset=uft-8");
require('fns.php');
require('upload.func.php');

// 名称字段不存在
define("ERR_CODE_NONAME", 1);
// 图片存储阶段失败
define("ERR_CODE_NOSAVE", 2);

// 专题id
$id = isset($_POST['id']) ? intval($_POST['id']) : false;

if (!isset($_FILES['imgfile']) || !$id) {
    showErr(ERR_CODE_NONAME, '缺少字段！');
}

// 存储目录的文件夹名称
$saveFolder = 'uploadfiles';
// 文件的存储路径(指向运行脚本所在的文件目录中)
$fileSavePath = getFilePath(__DIR__) . $saveFolder;
// 文件存储后可访问的http路径（指向运行脚本所在的文件目录中）
$currentFileName = basename(__FILE__);
$fileSaveServer = getFileUrl($currentFileName) . $saveFolder;

// 配置基本信息
$maxSize = 2 * 1024 * 1024;
$allowExt = array('jpeg', 'jpg', 'png', 'gif');

$fileInfo = $_FILES['imgfile'];

$imgSaveRes = uploadFile($fileInfo, $allowExt, true, $maxSize, $fileSavePath, $fileSaveServer);

// 检测是否成功
if ($imgSaveRes['success']) {
    showSuccess(array(
        $imgSaveRes['url']
    ));
} else {
    showErr(ERR_CODE_NOSAVE);
}