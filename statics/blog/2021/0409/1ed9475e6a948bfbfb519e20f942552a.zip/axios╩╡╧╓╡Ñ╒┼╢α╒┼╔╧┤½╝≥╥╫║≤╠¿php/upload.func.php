<?php 
// 循环多文件列表构建每个单个文件的信息
function getMultipleFiles($fileArr = []) {
    $files = array();
    foreach ($fileArr as $fileKey => $fileArr) {
        foreach ($fileArr as $index => $value) {
            $files[$index][$fileKey] = $value;
        }
    }
    return $files;
}



// 单文件上传封装
// $fileInfo = $_FILES['myfile'];

/*
$allowExt 允许上传的文件后缀名
$maxSize 文件允许上传的最大尺寸
$uploadPath 上传文件的文件目录
$flag 是否检查文件类型为图片
$uploadUrl 上传文件返回的图片路径URL
*/
function uploadFile(
    $fileInfo,
    $allowExt = array('jpeg', 'jpg', 'png', 'gif'),
    $flag = true,
    $maxSize = 2097152,
    $uploadPath = 'ups',
    $uploadUrl = ''
) {
    // 返回的信息
    $res = [
        // 是否成功
        'success' => false,
        // 失败的提示信息
        'msg' => '上传失败',
        // 原图片的文件的名称 
        'filename' => '',
        // 成功的文件名称
        'name' => '',
        // 成功返回的文件类型
        'type' => '',
        // 成功返回的文件尺寸
        'size' => '',
        // 成功返回的文件路径
        'path' => '',
        // 成功返回文件URL路径
        'url' => ''
    ];


    // 判断错误号
    if ($fileInfo['error'] > 0) {
        switch ($fileInfo['error']) {
            case 1:
                $mes = "上传文件超过了PHP配置文件中upload_max_filesize选项的值";
                break;
            case 2:
                $mes = "超过了表单MAX_FILE_SIZE限制大小";
                break;
            case 3:
                $mes = "文件部分被上传";
                break;
            case 4:
                $mes = "没有选中上传文件";
                break;
            case 6:
                $mes = "没有找到临时目录";
                break;
            case 7:
            case 8:
                $mes = "系统错误";
                break;
        }
        $res['msg'] = $mes;
        return $res;
    }

    $ext = pathinfo($fileInfo['name'], PATHINFO_EXTENSION);
    // $allowExt =  array('jpeg', 'jpg', 'png', 'gif');
    // 如果不是数组 提示系统错误
    if (!is_array($allowExt)) {
        $res['msg'] = '系统错误';
        return $res;
    }
    // 检测上传文件的类型
    if (!in_array($ext, $allowExt)) {
        $res['msg'] = '非法文件类型';
        return $res;
    }

    // 检测上传文件的大小是否符合规范
    if ($fileInfo['size'] > $maxSize) {
        $res['msg'] = '上传文件过大';
        return $res;
    }

    // 检测图片是否是真实图片类型,$flag默认是检测
    // $flag = true;
    if ($flag) {
        if (!@getimagesize($fileInfo['tmp_name'])) {
            $res['msg'] = '不是真实图片类型';
            return $res;
        }
    }


    // 检测文件是否通过HTTP POST方式上传上来
    if (!is_uploaded_file($fileInfo['tmp_name'])) {
        $res['msg'] = '文件不是通过HTTP POST方式上传上来';
        return $res;
    }

    // $uploadPath = '/ups';
    if (!file_exists($uploadPath)) {
        // 0777可读可写可执行 true最高权限
        mkdir($uploadPath, 0777, true);
        // 改变他的权限
        chmod($uploadPath, 0777);
    }
    // 产生一个唯一的文件名
    $uniName = md5(uniqid(microtime(true), true)).'.'.$ext;
    $destination = $uploadPath . '/' . $uniName;
    // 移动文件
    if (!@move_uploaded_file($fileInfo['tmp_name'], $destination)) {
        $res['msg'] = '文件移动失败';
        return $res;
    }

    // 迁移成功后拼接的访问url
    $destinationUrl = $uploadUrl . '/' .$uniName;

    // 上传成功 返回一些文件相关
    $res = [
        'success' => true,
        'msg' => '上传成功',
        'filename' => $fileInfo['name'],
        'name' => $uniName,
        'type' => $fileInfo['type'],
        'size' => $fileInfo['size'],
        'path' => $destination,
        'url' => $destinationUrl
    ];
    return $res;
}


 ?>