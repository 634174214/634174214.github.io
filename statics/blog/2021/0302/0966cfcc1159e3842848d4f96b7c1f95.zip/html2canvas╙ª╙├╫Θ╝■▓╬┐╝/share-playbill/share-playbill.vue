<template>
  <section class="share-playbill">
    <div class="share-btn" @click="openPlaybill"></div>
    <transition name="fadeIn">
      <div class="playbill" v-show="showPlaybill">
        <transition name="fadeInUp">
          <div class="playbill-inner" @click="closeTips" v-show="showPlaybill">
            <div class="playbill-inner-head">
              <div class="playbill-img-x">
                <img :src="playbillImg">
              </div>
            </div>
            <div class="playbill-inner-foot" @click="createPlaybillImg">
              <p>请长按图片保存分享到朋友圈</p>
              <div class="btns">
                <button @click.stop="toggleTipsShow">
                  {{showShareTips ? '关闭提示' : '分享到朋友圈'}}
                </button>
                <button @click.stop="closePlaybill" class="close-playbill-btn">关闭分享海报</button>
              </div>
            </div>
          </div>
        </transition>
        <transition name="sharetips-fadeInDown">
          <div class="share-tips" v-show="showShareTips"></div>
        </transition>
      </div>
    </transition>
    <dialog-tips message="抱歉，请在海报生成后尝试关闭" ref="dialogTips"></dialog-tips>
  </section>
</template>

<script type="text/ecmascript-6">
import { bodyScroll } from "common/js/tool";
import DialogTips from 'components/dialog-tips/dialog-tips';


export default {
  name: "share-playbill",
  props: {
    playbillImg: {
      type: String,
      default() {
        return '';
      }
    },
    playbillIsCreating: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  data() {
    return {
      showPlaybill: false,
      showShareTips: false,
      // 截屏图片
      screenImg: '',
      // 显示截屏的图片
      showScreenImg: false
    }
  },
  methods: {
    openPlaybill() {
      bodyScroll.stopBobyScroll();
      this.showPlaybill = true;
      this.$emit('open');
    },
    closePlaybill() {
      // 如果正在生成图片那么不允许关闭
      if (this.playbillIsCreating) {
        this.$refs.dialogTips.show();
        return;
      }
      this.$emit('close');
      this.showPlaybill = false;
      // 关闭的时候也要关闭微信分享提示
      this.closeTips();
      bodyScroll.allowBodyScroll();
    },
    closeTips() {
      this.showShareTips && (this.showShareTips = false);
    },
    toggleTipsShow() {
      this.showShareTips = !this.showShareTips;
    }
  },
  components: {
    DialogTips
  }
}
</script>

<style lang="less" rel="stylesheet/less">
  @import "~common/less/mixins.less";

  .share-btn {
    position: fixed;
    bottom: 40px;
    right: 4vw;
    width: 40px;
    height: 40px;
    z-index: var(--zt-zindex-V);
    .bg-image2x('share-btn', 'png');
    background-repeat: no-repeat;
    background-size: 100% auto;
  }


  .share-tips {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 28vh;
    border-radius: 0 0 10px 10px;
    background-color: rgba(0, 0, 0, 0.8);
    .bg-image2x('share-tips', 'png');
    background-position: top right;
  }

  .playbill {
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    z-index: var(--zt-zindex-MAX);
    background-color: rgba(0, 0, 0, 0.8);

    .playbill-inner {
      position: absolute;
      bottom: 0;
      background-color: #fff;
      width: 100%;
    }

    .playbill-inner-head {
      position: relative;
      padding: 10px 0 10px;

      .playbill-img-x{
        margin: 0 auto;
        .bg-image2x('playbill-create', 'gif');
        background-position: center center;
        background-size: 60px auto;
      }

      /* ipx以下 */
      @media screen and (min-width: 375px) {
        // 原300 * 520
        .playbill-img-x{
          width: 270px;
          height: 468px;
        }
      }

      /* ipx以下 */
      @media screen and (max-width: 374px) {
        .playbill-img-x{
          width: 200px;
          height: 348px;
        }
      }

      img{
        display: block;
        width: 100%;
        max-width: 300px;
        height: auto;
        box-shadow: 0px 2px 7px #ddd;
      }


      .playbill-close {
        position: absolute;
        font-size: var(--zt-font-size-IV);
        left: 10px;
        top: 10px;
      }
    }

    .playbill-inner-foot {
      padding: 10px 0 3vh;

      p {
        display: block;
        width: 100%;
        text-align: center;
        font-weight: 700;
        color: var(--zt-color-default);
      }

      .btns {
        margin-top: 15px;
        display: flex;
        justify-content: center;

        button {
          display: inline-block;
          background-color: var(--zt-color-default);
          border: 0;
          color: #fff;
          border-radius: 20px;
          width: 40vw;
          font-size: var(--zt-font-size-II);
          line-height: 40px;

          & + button {
            margin-left: 15px;
          }

          &.close-playbill-btn {
            background-color: #ccc;
          }
        }
      }
    }
  }
</style>
