import axios from "axios";
import { debug, ipAddress } from 'api/config';

const api = debug  ? `http://${ipAddress.yes ? ipAddress.ip : 'localhost'}/getxinpage/getbase64.php?url=` : 'http://m.qdxin.cn/appc/getbase64.php?url=';

export default function (target) {
  let url = api + target;
  return axios.get(url).then((res) => {
    return Promise.resolve(res.data);
  }).catch((err) => {
    return Promise.reject(err);
  })
}
