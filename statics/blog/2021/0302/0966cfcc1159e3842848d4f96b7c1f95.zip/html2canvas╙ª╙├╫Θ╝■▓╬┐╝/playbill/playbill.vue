<template>
  <section :class="'playbill-card-x ' + showPlaybillCard">
    <div :class="'playbill-card ' + playbillCls" ref="playbillCard">
      <!--  主页分享 -->
      <div class="index-card">
        <div class="card-top">
            <span class="img-x">
              <img :src="billImgIndex"
                   @load="imageLoaded"
                   :data-show="billImgIndex ? true : false"
              >
            </span>
        </div>
      </div>
      <!--  主页分享 end -->
      <!-- 详细页分享 -->
      <div class="detail-card">
        <div class="detail-card-inner">
          <div class="card-top">
            <div class="img-x">
              <img :src="billImgDetail"
                   @load="imageLoaded"
                   :data-show="billImgDetail ? true : false"
              >
            </div>
            <article class="article-x">
              <h3>{{billTitle}}</h3>
              <p>{{billDesc}}</p>
            </article>
          </div>
        </div>
      </div>
      <!-- 详细页分享 end -->
      <div class="news-info">
        <div class="info-x">
          <span class="zt-logo">
            <img :src="ztlogo" alt="信网专题">
          </span>
          <h3 class="news-title">独家视角审视青岛生活</h3>
          <p class="news-tips">长按识别二维码 阅读文章详情</p>
        </div>
        <span class="qrbox" ref="qrbox"></span>
        <span class="clear"></span>
      </div>
    </div>
  </section>
</template>

<script type="text/ecmascript-6">
import html2canvas from 'html2canvas';
import QRCode from 'qrcodejs2';
import getBase64 from "api/getBase64";
import { doPlaybill } from "common/js/tool";
import { ERR_OK } from 'api/config';


export default {
  name: "playbill",
  data() {
    return {
      billTitle: '',
      billDesc: '',
      billImg: '',
      // 默认的图片
      billImgIndex: '',
      billImgDetail: '',
      billLink: '',
      billComponent: '',
      showCard: false,
      // 是否是在生成图片的异步操作中
      isCreating: false
    }
  },
  computed: {
    playbillCls() {
      let cls = '';
      switch (this.billComponent) {
        case 'index':
          cls = 'isIndex';
          break;
        case 'detail':
          cls = 'isDetail';
          break;
        default:
          cls = '';
      }
      return cls;
    },
    ztlogo() {
      return require('../playbill/zt-logo@2x.png');
    },
    showPlaybillCard() {
      return this.showCard ? 'show' : '';
    }
  },
  methods: {
    createCard() {
      this.isCreating = true;
      // 当开始生成图片时，发送事件通知外部进入等待状态,同时点击关闭会失效
      this.$emit('creating', this.isCreating);

      this.getPlaybillInfo();
      this.createQrCode();
      // 初始化之后就生成二维码
      this.qrcode.makeCode(this.billLink);
      this.getBase64Img();

      // 1秒后显示
      // setTimeout(() => {
      //   this.showCard = true;
      // }, 1000);
    },
    // 大图加载完毕后执行
    imageLoaded(e) {
      // 排除重复执行的问题
      if (!e.target.dataset.show) {
        return;
      }
      setTimeout(() => {
        this.createPlaybillImg();
      }, 20);
    },
    createPlaybillImg() {
      console.log('creating img!');
      let card = this.$refs.playbillCard;
      let cardWidth = card.offsetWidth;
      let cardHeight = card.offsetHeight;

      html2canvas(card, {
        // 缺少了就会显示空白！！
        useCORS: true,
        width: cardWidth,
        height: cardHeight,
        windowWidth: document.body.scrollWidth,
        windowHeight: document.body.scrollHeight,
        x: 0,
        y: window.pageYOffset,
        // 可解决图片不透明问题以及有白边
        backgroundColor: null,
      }).then((canvas) => {
        // canvas.setAttribute('id', 'thecanvas');
        // document.body.appendChild(canvas);
        canvas.setAttribute('id','thecanvas');
        var context = canvas.getContext('2d');
        context.mozImageSmoothingEnabled = false;
        context.webkitImageSmoothingEnabled = false;
        context.msImageSmoothingEnabled = false;
        context.imageSmoothingEnabled = false;
        // image/jpeg的时候第二个参数可以选择图片的质量 默认0.92 取值0-1
        let data = canvas.toDataURL("image/jpeg");
        // console.log(data);
        // 生成图片后，向外部发送事件
        this.isCreating = false;
        this.$emit('created', data, this.isCreating);
      });
    },
    getPlaybillInfo() {
      let info = doPlaybill.get();
      this.billTitle = info.title;
      this.billDesc = info.desc;
      this.billImg = info.img;
      this.billComponent = info.component;
      this.billLink = info.link;
    },
    getBase64Img() {
      // 如果没有图片那么就不请求
      if (!this.billImg) {
        this.noBillImg();
        return;
      }
      getBase64(this.billImg).then((res) => {
        if (res.error === ERR_OK) {
          if (!res.data) {
            this.noBillImg();
            return;
          }
          this.billImgBase64(res.data);
        }
      }).catch(() => {
        // 分享图获取失败 抛出error
        this.$emit('error');
        window.alert('分享图获取失败，请稍后重试');
      })
    },
    billImgBase64(base64) {
      switch (this.billComponent) {
        case 'index':
          this.billImgIndex = base64;
          break;
        case 'detail':
          this.billImgDetail = base64;
          break;
      }
    },
    // 如果没有图片那么根据情况选择显示不同的图片赋予base64作为主图
    noBillImg() {
      switch (this.billComponent) {
        case 'index':
          this.billImgIndex = require('../playbill/no-img-index.jpg');
          break;
        case 'detail':
          this.billImgDetail = require('../playbill/no-news-image@2x.jpg');
          break;
      }
      console.log(this.billImgDetail)
    },
    createQrCode() {
      this.qrcode = new QRCode(this.$refs.qrbox, {
        width: 128,
        height: 128,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
      });
    },
    resetData() {
      this.showCard = false;
      this.billTitle = '';
      this.billDesc = '';
      this.billImg = '';
      this.billImgDetail = '';
      this.billImgIndex = '';
      this.billLink = '';
      this.billComponent = '';
    },
    clearQrCode() {
      this.qrcode.clear(); // 清除代码
      this.$refs.qrbox.innerHTML = '';
    },
    destoryCard() {
      this.clearQrCode();
      this.resetData();
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less">
  @import "~common/less/mixins.less";

  @cardHeight: 520px;
  @cardMainHeight: 430px;

  .playbill-card-x {
    overflow: hidden;
    position: fixed;
    // 不能是Bottom 否则截图会是黑屏
    top: 0;
    left: 0;
    opacity: 0;
    z-index: -1;
    // 经过测试，档z-index=-1时候 依然可以截图 但是不可以隐藏
    &.show{
      z-index: var(--zt-zindex-IX);
      /*z-index: 10000;*/
    }
  }

  .clear{
    display: block;
    clear: both;
  }

  .card-top {
    height: @cardMainHeight;
  }

  .news-info {
    padding: 15px 10px;
    align-items: center;
    box-sizing: border-box;

    .info-x {
      width: 200px;
      height: 60px;
      float: left;
      overflow: hidden;

      .news-title {
        font-weight: 700;
        font-size: 16px;
        width: 100%;
        padding: 6px 0 5px;
      }

      .news-tips {
        color: #7B7B7B;
        font-size: 12px;
      }

      .zt-logo {
        text-indent: -9999em;
        display: block;
        width: 120px;
        height: 20px;
        background-position: left center;
        background-size: auto 100%;
        img{
          width: auto;
          height: 100%;
          display: block;
        }
      }
    }

    .qrbox {
      float: right;
      width: 60px;
      height: 60px;
      img{
        display: block;
        width: 100%;
        height: auto;
      }
    }
  }

  .playbill-card {
    width: 300px;
    box-sizing: border-box;
    margin: 0 auto;
    height: @cardHeight;
    background-color: #f4f4f4;
    overflow: hidden;
    position: relative;

    .index-card
    .detail-card
    {
      img {
        display: none;
        width: 100%;
      }
      &[data-show="true"] {
        display: block;
      }
    }


    .index-card {
      .card-top {
        background-color: #fff;
        padding: 10px;
        box-sizing: border-box;

        .img-x {
          display: block;
          height: @cardMainHeight - 20px;
          overflow: hidden;
        }

        img {
          width: 300px;
          height: auto;
          margin-top: -25%;
        }
      }
    }

    .detail-card {
      box-sizing: border-box;

      .detail-card-inner {
        background-color: #fff;
        border-radius: 10px 10px 0 0;
        overflow: hidden;

        .card-top {
          height: @cardMainHeight - 20px;
          overflow: hidden;
          position: relative;

          &:after {
            content: "";
            position: absolute;
            width: 100%;
            height: 100px;
            bottom: 0;
            background: url("alpha@2x.png") bottom left;
          }
        }

        .img-x {
          height: 170px;
          overflow: hidden;

          img {
            min-width: 100%;
            height: 100%;
          }
        }

        .article-x {
          padding: 10px 15px;
          box-sizing: border-box;
          height: @cardMainHeight - 170px - 20px;
          overflow: hidden;
          position: relative;

          h3 {
            font-weight: 700;
            line-height: 1.3em;
            margin-bottom: 5px;
          }

          p {
            font-size: 13px;
            line-height: 1.6em;

          }
        }
      }
    }
  }

  // 通过样式控制主页和详细页不同的显示隐藏
  .playbill-card {
    & > div:not(.news-info) {
      display: none;
    }

    &.isIndex {
      .index-card {
        display: block;
      }
    }

    &.isDetail {
      padding: 10px;

      .detail-card {
        display: block;
      }

      .news-info {
        position: relative;
        background-color: #fff;

        &:before,
        &:after {
          content: "";
          position: absolute;
          background-color: #f4f4f4;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          top: -10px;
        }

        &:before {
          left: -10px;
        }

        &:after {
          right: -10px;
        }
      }
    }
  }
</style>
