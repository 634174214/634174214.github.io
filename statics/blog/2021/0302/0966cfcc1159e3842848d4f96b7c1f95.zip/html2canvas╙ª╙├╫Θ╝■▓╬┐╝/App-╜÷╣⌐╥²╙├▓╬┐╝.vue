<template>
  <section class="main">

      <router-view v-slot="{ Component }">
          <transition name="aside-right" appear>
            <!--  加入keep-alive保证进入退出都有动画 -->
            <!--  exclude排除缓存，让其不缓存数据 -->
            <keep-alive exclude="detail">
              <component :is="Component"  @closeDetail="indexShareConfig"/>
            </keep-alive>
          </transition>
      </router-view>

    <playbill ref="playbill"
              @created="createdPlaybill"
              @creating="creatingPlaybill"
              @error="createError"
    ></playbill>
    <share-playbill @open="openPlaybill"
                    @close="closePlaybill"
                    :playbillImg="playbillImg"
                    :playbillIsCreating="playbillIsCreating"
    ></share-playbill>
  </section>

</template>

<script type="text/ecmascript-6">
import { bodyScroll, doPlaybill, isPcShow } from "common/js/tool";
import { ERR_OK, defaultShareImg } from 'api/config';
import { shareConfig } from "common/js/wxshare";

import SharePlaybill from 'components/share-playbill/share-playbill';
import Playbill from 'components/playbill/playbill';

let needWatch = true;

export default {
  name: 'App',
  data() {
    return {
      all: {},
      allImages: [],
      playbillImg: '',
      playbillIsCreating: false
    }
  },
  created() {
    bodyScroll.stopBobyScroll();
    this.getMainList();
  },
  methods: {
    getMainList() {
      GetMain().then(res => {
        if (res.error === ERR_OK) {
          // console.log(res.data)
          this.all = res.data;
        }
      })
    },
    openPlaybill() {
      this.$refs.playbill.createCard();
    },
    closePlaybill() {
      // 当关闭的时候重置图片链接
      this.playbillImg = '';
      this.$refs.playbill.destoryCard();
    },
    createdPlaybill(imgData, isCreating) {
      this.playbillImg = imgData;
      this.playbillIsCreating = isCreating;
    },
    creatingPlaybill(isCreating) {
      this.playbillIsCreating = isCreating;
    },
    // 分享失败时候执行关闭海报板块
    createError() {
      this.closePlaybill();
    },
    setPageInfo() {
      document.title = this.all.title;
      document.querySelector('meta[name="keywords"]').content = this.all.keywords;
      document.querySelector('meta[name="description"]').content = this.all.description;
    },
    // 应用皮肤样式
    setSkin() {
      document.body.dataset.skin = this.all.skin;
      // 在body上设置默认的分享图
      document.body.dataset.shareimg = this.all.shareimg ? this.all.shareimg : defaultShareImg;
    },
    // 获取所有图片资源
    getAllImages() {
      let allStr = JSON.stringify(this.all);
      let pattern = /((http|https):\/\/)+(\w+\.)+(\w+)[\w/.-]*(jpg|gif|png)/gi;
      // console.log(allStr);
      this.allImages = allStr.match(pattern);
    },
    indexShareConfig() {
      shareConfig({
        wxtitle: this.all.title,
        title: this.all.title,
        desc: this.all.description,
        keywords: this.all.keywords,
        imgsrc: this.all.shareimg,
        link: ''
      });
      // 设置分享海报的信息
      doPlaybill.set({
        component: 'index',
        img: this.all.cover,
        title: this.all.title,
        desc: this.all.description
      });
    },
    setPcShow() {
      isPcShow(this.all.cover);
    }
  },
  watch: {
    all(val) {
      if (needWatch && val) {
        this.setPageInfo();
        this.setSkin();
        this.getAllImages();
        this.indexShareConfig();
        this.setPcShow();
        needWatch = false;
      }
    }
  },
  components: {
    MainList,
    Cover,
    SharePlaybill,
    Loading,
    TopLink,
    Playbill
  }
}
</script>

<style>

</style>
